package yl.net.jay.myapplication.utils;

public class Resources {
    private String title;
    private String chaodai;
    private String content;
    private String yiwen;
    private String zhushi;
    private String shangxi;
    private String pinxi;
    private String[] tag;

    public String[] getTag() {
        return tag;
    }

    public void setTag(String[] tag) {
        this.tag = tag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getChaodai() {
        return chaodai;
    }

    public void setChaodai(String chaodai) {
        this.chaodai = chaodai;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getYiwen() {
        return yiwen;
    }

    public void setYiwen(String yiwen) {
        this.yiwen = yiwen;
    }

    public String getZhushi() {
        return zhushi;
    }

    public void setZhushi(String zhushi) {
        this.zhushi = zhushi;
    }

    public String getShangxi() {
        return shangxi;
    }

    public void setShangxi(String shangxi) {
        this.shangxi = shangxi;
    }

    public String getPinxi() {
        return pinxi;
    }

    public void setPinxi(String pinxi) {
        this.pinxi = pinxi;
    }
}
