package yl.net.jay.myapplication.example;

public class DialogM {
    private String name;
    private String content;
    private int zannum2;
    private  int isZan;

    public int getIsZan() {
        return isZan;
    }

    public void setIsZan(int isZan) {
        this.isZan = isZan;
    }

    public int getZannum2() {
        return zannum2;
    }

    public void setZannum2(int zannum2) {
        this.zannum2 = zannum2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
