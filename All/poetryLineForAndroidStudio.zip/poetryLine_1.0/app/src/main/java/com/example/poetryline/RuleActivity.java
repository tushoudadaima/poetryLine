package com.example.poetryline;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class RuleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rule);
    }
}
