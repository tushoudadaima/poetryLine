package com.example.poetryline.detail.utils;

public class zuoXiang {
    String name;
    String jianjie;
    String yishidiangu;
    String jiatingchengyuan;
    String houshijinian;
    String zhuyaochengjiu;
    String renwushengpin;
}
