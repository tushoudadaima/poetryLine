package com.example.poetryline.fragment;

public class Gushi {
    private String title;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    public Gushi(String title){
        this.title=title;
    }
}
