package com.example.poetryline.detail.Send;

public class Pin {
    private String text1;
    private String textm;
    private String textz;
    private String textp;
    private int imgg;

    public int getImgg() {
        return imgg;
    }

    public void setImgg(int imgg) {
        this.imgg = imgg;
    }

    public String getText1() {
        return text1;
    }

    public void setText1(String text1) {
        this.text1 = text1;
    }

    public String getTextm() {
        return textm;
    }

    public void setTextm(String textm) {
        this.textm = textm;
    }

    public String getTextz() {
        return textz;
    }

    public void setTextz(String textz) {
        this.textz = textz;
    }

    public String getTextp() {
        return textp;
    }

    public void setTextp(String textp) {
        this.textp = textp;
    }
}
