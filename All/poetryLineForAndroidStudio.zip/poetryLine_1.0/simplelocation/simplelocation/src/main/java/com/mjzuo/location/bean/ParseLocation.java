package com.mjzuo.location.bean;

public abstract class ParseLocation<T> {

    public abstract Latlng paseLocation(T t);
}
